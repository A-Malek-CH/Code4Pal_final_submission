import os
from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	SerplyWebSearchTool,
	QdrantVectorSearchTool
)





@CrewBase
class HealthcareDonorPatientMatchingSystemCrew:
    """HealthcareDonorPatientMatchingSystem crew"""

    
    @agent
    def donor_patient_matching_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["donor_patient_matching_specialist"],
            
            
            tools=[
				SerplyWebSearchTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
        )
    
    @agent
    def medical_data_analyst(self) -> Agent:
        
        return Agent(
            config=self.agents_config["medical_data_analyst"],
            
            
            tools=[
				QdrantVectorSearchTool(qdrant_url="http://localhost:6333")
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
        )
    
    @agent
    def healthcare_institution_advisor(self) -> Agent:
        
        return Agent(
            config=self.agents_config["healthcare_institution_advisor"],
            
            
            tools=[
				SerplyWebSearchTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
        )
    
    @agent
    def financial_assistance_coordinator(self) -> Agent:
        
        return Agent(
            config=self.agents_config["financial_assistance_coordinator"],
            
            
            tools=[
				SerplyWebSearchTool()
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
        )
    

    
    @task
    def find_compatible_donors_and_financial_support(self) -> Task:
        return Task(
            config=self.tasks_config["find_compatible_donors_and_financial_support"],
            markdown=False,
        )
    
    @task
    def analyze_medical_data_for_routing(self) -> Task:
        return Task(
            config=self.tasks_config["analyze_medical_data_for_routing"],
            markdown=False,
        )
    
    @task
    def recommend_healthcare_institutions(self) -> Task:
        return Task(
            config=self.tasks_config["recommend_healthcare_institutions"],
            markdown=False,
        )
    
    @task
    def identify_financial_assistance_opportunities(self) -> Task:
        return Task(
            config=self.tasks_config["identify_financial_assistance_opportunities"],
            markdown=False,
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the HealthcareDonorPatientMatchingSystem crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )
